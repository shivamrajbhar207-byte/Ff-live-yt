# मोबाइल से APK बनाना (GitHub Actions)

इस प्रोजेक्ट में APK बनाने के लिए Android SDK फोन पर इंस्टॉल करने की जरूरत नहीं। GitHub Actions क्लाउड में build करेगा।

1. GitHub पर अकाउंट बनाएं/लॉगिन करें: https://github.com
2. `New repository` बनाएं। नाम `ff-live-mic` रखें और `Private` चुनें।
3. फोन के ब्राउज़र में repository खोलें। `Add file` > `Upload files` चुनें। ZIP को पहले फोन में Extract करें, फिर उसके अंदर के प्रोजेक्ट की सभी फाइलें/फ़ोल्डर (खासकर `.github` सहित) अपलोड करें। GitHub वेबसाइट पर hidden `.github` फ़ोल्डर दिखाने/अपलोड करने में कठिनाई हो तो GitHub मोबाइल ऐप के बजाय Chrome में Desktop site चालू करें।
4. `Commit changes` दबाएं।
5. Repository में `Actions` टैब खोलें। `Build Android APK` workflow चुनें। `Run workflow` दबाएं।
6. Build पूरा होने पर workflow run खोलें। नीचे `Artifacts` में `FF-Live-Mic-debug-apk` डाउनलोड करें। ZIP के अंदर `app-debug.apk` होगा।
7. APK अपने Redmi 13 में खोलें। Android पूछे तो Chrome/Files को इस स्रोत से ऐप इंस्टॉल करने की अनुमति दें। केवल अपनी बनाई हुई APK इंस्टॉल करें।

ध्यान दें: यह debug APK होगा, Play Store release नहीं। Source अभी पहले से build/test नहीं हुआ है; workflow में compilation error आए तो Actions के लाल build log को साझा करें। YouTube stream key को GitHub पर कभी commit न करें; वह केवल ऐप में डालें।

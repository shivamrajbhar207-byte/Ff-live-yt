# Phase 0.8 implementation notes

The previous ImageReader + separate AudioRecord + standalone AAC encoder prototype was replaced in the active service path by RootEncoder's integrated streaming abstractions:

- `ScreenSource(applicationContext, mediaProjection)` supplies screen frames.
- `MixAudioSource(mediaProjection)` captures microphone and permitted internal playback as one PCM source on Android Q+.
- `RtmpStream(context, ConnectChecker, videoSource, audioSource)` prepares H.264/AAC and publishes RTMP.

The app now requests the YouTube server URL and stream key at runtime. The final publish URL is assembled only in memory and is never logged. The connection checker updates the foreground notification for connection, authentication and bitrate events.

On Android versions below Q, the app falls back to `MicrophoneSource` because Android playback capture is unavailable.

Build/device validation remains outstanding. See PROJECT_STATUS.txt.

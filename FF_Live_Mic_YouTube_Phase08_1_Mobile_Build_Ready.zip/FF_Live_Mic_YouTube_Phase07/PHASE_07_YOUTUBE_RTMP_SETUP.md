# FF LIVE MIC — Phase 0.7: YouTube RTMP setup foundation

## Added in this phase
- RootEncoder 2.8.1 dependency and JitPack repository for Android RTMP/H.264/AAC publishing.
- INTERNET permission.
- `YouTubeRtmpConfig` validation helper for YouTube's server URL + stream key.
- Stream key is represented only as an in-memory value in this helper; do not log it, commit it, or put it in analytics/crash reports.

## Important: not a finished live-stream build
This phase does **not** yet connect the existing MediaProjection + mixed PCM pipeline to RootEncoder.
The current `CaptureService` still drains screen frames and sends AAC packets only to Logcat. It does not publish RTMP.
The app therefore must not be advertised or used as a working YouTube streamer yet.

## Next implementation work
1. Use RootEncoder's screen/DisplayBase (or custom source) path to publish MediaProjection frames as H.264.
2. Feed the existing mixed PCM (mic + Android playback capture) into RootEncoder's custom audio source, rather than opening a second microphone capture.
3. Mux/publish AAC + H.264 through RTMP; add connection callbacks, reconnect/backoff, bitrate and stop handling.
4. Test on the target Android phone and with a private/unlisted YouTube stream before public use.

## YouTube setup
In YouTube Studio, create/schedule a live stream and copy the exact server URL and stream key shown there. Never share the stream key in chat or screenshots. Rotate it in YouTube Studio if it is exposed.

## Platform limitations
- Android playback capture requires Android 10+ and the game must allow capture; some games/devices may return silence.
- MediaProjection requires the user's explicit screen-capture consent each session.
- Microphone/game audio balance and A/V sync require device testing.

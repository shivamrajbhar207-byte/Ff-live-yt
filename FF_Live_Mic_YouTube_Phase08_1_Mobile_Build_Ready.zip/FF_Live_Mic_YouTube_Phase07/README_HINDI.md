# FF LIVE MIC — YouTube Live Android Source (Phase 0.8.1)

यह Android Studio project Free Fire जैसे गेम की स्क्रीन को RootEncoder के जरिए H.264 में encode करके YouTube Live के RTMP/RTMPS ingest पर भेजने के लिए बनाया गया है। Android 10+ पर यह `MixAudioSource` से microphone और अनुमति-प्राप्त internal playback audio को एक PCM source में मिलाकर AAC encode करता है। Android 8/9 पर microphone-only fallback है।

## मुख्य सुविधाएँ
- MediaProjection consent के बाद स्क्रीन capture
- RootEncoder 2.8.1 `ScreenSource` + `RtmpStream`
- H.264 video: 720p तक (डिवाइस स्क्रीन के अनुपात के अनुसार), 30 FPS लक्ष्य, 2.5 Mbps
- AAC audio: 44.1 kHz stereo, 128 kbps
- Android 10+ पर Mic + internal game playback mix; Mic gain 1.5x, internal 0.85x
- Foreground service और notification से STOP LIVE action
- YouTube server URL और stream key ऐप में runtime पर भरें; stream key source code में hard-code नहीं है
- Stream key को log नहीं किया जाता; field submit के बाद साफ हो जाती है

## Build
1. Android Studio में इस फ़ोल्डर को खोलें: `FF_Live_Mic_YouTube_Phase07`
2. Android SDK Platform 35 और JDK 17 इंस्टॉल रखें।
3. Gradle sync करें; JitPack repository `settings.gradle.kts` में configured है।
4. `app` configuration को किसी Android 8.0+ डिवाइस पर Run करें।

इस workspace में Android SDK/Gradle उपलब्ध नहीं थे, इसलिए APK compile/sign या device test का दावा नहीं किया जा रहा।

## YouTube पर चलाने के चरण
1. YouTube Studio → Go Live → Stream में जाएँ।
2. Studio में दिखाया Server URL और Stream Key ऐप में भरें। Stream key निजी रखें।
3. START YOUTUBE LIVE दबाएँ और Android screen-capture अनुमति दें।
4. Free Fire खोलें। YouTube Studio के Preview/Stream health में video और audio जाँचें।
5. YouTube Studio से Go Live करें। बंद करने के लिए ऐप या foreground notification में STOP LIVE दबाएँ।

## जरूरी सीमाएँ
- Internal audio capture Android 10+ पर ही उपलब्ध है। Android playback-capture policy और गेम की audio usage/policy अनुमति दे तो ही गेम की आवाज़ मिलेगी। कोई ऐप capture रोक सकता है।
- Android device के H.264/AAC MediaCodec support पर encoder preparation निर्भर है।
- फोन की screen rotation, thermal throttling, upload bandwidth और network stability के अनुसार परिणाम बदलेंगे।
- RTMP (बिना TLS) में stream key transport encryption से सुरक्षित नहीं रहती; YouTube Studio RTMPS endpoint उपलब्ध कराए तो वही इस्तेमाल करें।
- YouTube Studio में final Go Live कार्रवाई अलग से करनी पड़ सकती है।

## सुरक्षा
किसी को stream key न भेजें, screenshot न लें और public repository में न रखें। स्ट्रीमिंग बंद करने के बाद YouTube Studio में जरूरत हो तो key reset करें।
